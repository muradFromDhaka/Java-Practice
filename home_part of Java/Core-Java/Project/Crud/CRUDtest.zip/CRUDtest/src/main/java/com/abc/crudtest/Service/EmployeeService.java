/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abc.crudtest.Service;

import com.abc.crudtest.entity.Employee;
import com.abc.crudtest.repository.DatabaseConnectionTest;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

/**
 *
 * @author B-2
 */
public class EmployeeService {
    
    // Employee add;
    public void addEmployee(Employee emp){
        String sql = "INSERT INTO employees (name,age,dateOfBirth,salary,address) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conn = DatabaseConnectionTest.getConnetion();
            PreparedStatement ps = conn.prepareStatement(sql);
            
           // ps.setLong(1, emp.getId());
            ps.setString(1, emp.getName());
            ps.setInt(2, emp.getAge());
            ps.setDate(3, Date.valueOf(emp.getdateOfBirth()));
            ps.setBigDecimal(4, emp.getSalary());
            ps.setString(5, emp.getAddress());
            
            ps.executeUpdate();
            System.out.println("Employee added successfully.");
            
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
